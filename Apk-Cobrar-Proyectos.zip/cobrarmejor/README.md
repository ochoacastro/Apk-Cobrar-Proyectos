# CobrarMejor — APK via GitHub Actions

## Pasos para generar la APK (sin instalar nada)

### 1. Crear repositorio en GitHub
1. Ve a https://github.com/new
2. Nombre: `cobrarmejor`
3. Selecciona **Privado** o Público
4. Clic en **Create repository**

### 2. Subir estos archivos
En la página del repo recién creado:
1. Clic en **uploading an existing file**
2. Arrastra TODOS los archivos y carpetas de este ZIP
3. Clic en **Commit changes**

### 3. Esperar la compilación
1. Ve a la pestaña **Actions** del repo
2. Verás el workflow `Build APK` corriendo (tarda ~5-8 minutos)
3. Cuando termine, clic en el workflow completado
4. Abajo en **Artifacts** descarga `CobrarMejor-debug`
5. Descomprime y tendrás `app-debug.apk`

### 4. Instalar la APK en Android
1. Pasa el archivo `app-debug.apk` a tu teléfono
2. Abre el archivo desde el gestor de archivos
3. Si pide permiso para "instalar apps desconocidas", acéptalo
4. ¡Listo!

---

## Estructura del proyecto

```
cobrarmejor/
├── www/
│   └── index.html          ← La app completa
├── .github/
│   └── workflows/
│       └── build.yml       ← Compilación automática
├── capacitor.config.json   ← Configuración de Capacitor
├── package.json            ← Dependencias
└── README.md               ← Este archivo
```

## Nota sobre la APK debug
La APK generada es una versión **debug** (para uso personal).
Si quieres publicarla en Google Play, necesitarías firmarla con un keystore.
