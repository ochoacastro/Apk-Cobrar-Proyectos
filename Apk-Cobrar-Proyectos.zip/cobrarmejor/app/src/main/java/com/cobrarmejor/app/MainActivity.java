package com.cobrarmejor.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1;
    private static final int NOTIF_PERMISSION_REQUEST = 2;
    private static final String CHANNEL_ID = "cobros_pendientes";
    private static final int NOTIF_ID = 1001;

    // ── JavaScript Bridge ──────────────────────────────────────────────
    public class AppBridge {

        @JavascriptInterface
        public void reportPending(int count) {
            runOnUiThread(() -> {
                if (count > 0) {
                    showPendingNotification(count);
                } else {
                    clearNotification();
                }
            });
        }
    }

    // ── onCreate ───────────────────────────────────────────────────────
    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );

        createNotificationChannel();
        requestNotificationPermission();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Expose bridge to JavaScript as window.Android
        webView.addJavascriptInterface(new AppBridge(), "Android");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("https://wa.me") || url.startsWith("http")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                // Once page is loaded, ask JS to count pending payments
                view.evaluateJavascript(
                    "(function() {" +
                    "  try {" +
                    "    var raw = localStorage.getItem('cobrarMejor_projects');" +
                    "    if (!raw) { Android.reportPending(0); return; }" +
                    "    var projects = JSON.parse(raw);" +
                    "    var today = new Date().toISOString().slice(0,7);" +
                    "    var count = 0;" +
                    "    projects.forEach(function(p) {" +
                    "      if (!p.schedule) return;" +
                    "      p.schedule.forEach(function(s) {" +
                    "        if (!s.paid && s.month <= today) count++;" +
                    "      });" +
                    "    });" +
                    "    Android.reportPending(count);" +
                    "  } catch(e) { Android.reportPending(0); }" +
                    "})();",
                    null
                );
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    // ── Notification helpers ───────────────────────────────────────────
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Cobros pendientes",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Avisa cuántos cobros están pendientes");
            channel.setShowBadge(true);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this,
                    android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{ android.Manifest.permission.POST_NOTIFICATIONS },
                    NOTIF_PERMISSION_REQUEST);
            }
        }
    }

    private void showPendingNotification(int count) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String title = count == 1
            ? "1 cobro pendiente"
            : count + " cobros pendientes";
        String body = count == 1
            ? "Tienes 1 pago por cobrar este mes"
            : "Tienes " + count + " pagos por cobrar";

        Notification notif = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setNumber(count)           // <-- este es el badge number
            .setContentIntent(pi)
            .setAutoCancel(false)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build();

        NotificationManagerCompat nm = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED || 
                Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            nm.notify(NOTIF_ID, notif);
        }
    }

    private void clearNotification() {
        NotificationManagerCompat.from(this).cancel(NOTIF_ID);
    }

    // ── onResume: refresh badge every time app comes to foreground ─────
    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.evaluateJavascript(
                "(function() {" +
                "  try {" +
                "    var raw = localStorage.getItem('cobrarMejor_projects');" +
                "    if (!raw) { Android.reportPending(0); return; }" +
                "    var projects = JSON.parse(raw);" +
                "    var today = new Date().toISOString().slice(0,7);" +
                "    var count = 0;" +
                "    projects.forEach(function(p) {" +
                "      if (!p.schedule) return;" +
                "      p.schedule.forEach(function(s) {" +
                "        if (!s.paid && s.month <= today) count++;" +
                "      });" +
                "    });" +
                "    Android.reportPending(count);" +
                "  } catch(e) { Android.reportPending(0); }" +
                "})();",
                null
            );
        }
    }

    // ── onActivityResult ───────────────────────────────────────────────
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK && data != null) {
                    results = new Uri[]{ data.getData() };
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
